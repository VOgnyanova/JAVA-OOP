package _03_Person;

public class Child extends  Person{
    public Child(String name, int age) {
        super(name, age);
    }
}
