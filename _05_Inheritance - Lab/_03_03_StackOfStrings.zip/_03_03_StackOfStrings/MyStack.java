package _03_03_StackOfStrings;

import java.util.ArrayDeque;

public class MyStack  extends ArrayDeque<String> {
}
