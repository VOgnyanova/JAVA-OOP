package BorderControl;

public interface Identifiable {
    String getId();
}
