package BirthdayCelebrations;

public interface Birthable {
    String getBirthDate();
}
