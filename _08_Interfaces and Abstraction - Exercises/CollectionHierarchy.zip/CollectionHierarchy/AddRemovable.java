package CollectionHierarchy;

public interface AddRemovable extends Addable {
     String remove();

}
