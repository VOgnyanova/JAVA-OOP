package _04_TrafficLights;

public enum Color {
    RED,
    YELLOW,
    GREEN
}
