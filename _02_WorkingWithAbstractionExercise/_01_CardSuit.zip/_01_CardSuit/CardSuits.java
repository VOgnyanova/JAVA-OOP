package _01_CardSuit;

public enum CardSuits {

    CLUBS,DIAMONDS, HEARTS,SPADES



}
